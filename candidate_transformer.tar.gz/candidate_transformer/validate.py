"""Validate output records against a JSON schema before returning them."""
import json
from typing import Dict, List, Tuple

try:
    import jsonschema
except ImportError:
    jsonschema = None


def load_schema(path: str) -> Dict:
    with open(path) as f:
        return json.load(f)


def validate_record(record: Dict, schema: Dict) -> Tuple[bool, List[str]]:
    if jsonschema is None:
        return True, ["jsonschema library not installed -- validation skipped"]
    validator = jsonschema.Draft7Validator(schema)
    errors = [f"{'.'.join(str(p) for p in e.path)}: {e.message}" for e in validator.iter_errors(record)]
    return (len(errors) == 0), errors
