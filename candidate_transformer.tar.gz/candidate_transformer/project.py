"""Project a canonical candidate record into a custom shape per a runtime config.

Keeps a clean separation: the canonical record never changes shape; only this
layer reads the config and reshapes the *output*. Same engine, no code changes
needed to alter the output schema.
"""
from typing import Dict, List, Any
from normalize import normalize_phone, normalize_skill


def _get_path(record: Dict, path: str) -> Any:
    """Resolve a simple dotted/bracket path like 'emails[0]' or 'skills[].name'."""
    if path.endswith("[].name"):
        base = path[: -len("[].name")]
        items = record.get(base) or []
        return [item.get("name") for item in items if isinstance(item, dict)]
    if path.endswith("]"):
        base, idx = path[:-1].split("[")
        items = record.get(base) or []
        idx = int(idx)
        return items[idx] if 0 <= idx < len(items) else None
    return record.get(path)


def _apply_missing_policy(value, policy: str):
    if value is not None:
        return value, True  # (value, keep_field)
    if policy == "omit":
        return None, False
    if policy == "error":
        raise ValueError("required field missing and on_missing=error")
    return None, True  # null


def project(record: Dict, config: Dict) -> Dict:
    on_missing = config.get("on_missing", "null")
    out: Dict[str, Any] = {}

    for field_spec in config.get("fields", []):
        target = field_spec["path"]
        source_path = field_spec.get("from", target)
        value = _get_path(record, source_path)

        norm = field_spec.get("normalize")
        if norm == "E164":
            value = normalize_phone(value) if isinstance(value, str) else value
        elif norm == "canonical" and isinstance(value, list):
            value = [normalize_skill(v) for v in value if v]

        if field_spec.get("required") and value is None and on_missing == "error":
            raise ValueError(f"required field '{target}' missing")

        value, keep = _apply_missing_policy(value, on_missing)
        if keep:
            out[target] = value

    if config.get("include_confidence", True):
        out["overall_confidence"] = record.get("overall_confidence")
    if config.get("include_provenance", False):
        out["provenance"] = record.get("provenance")

    return out


def project_all(records: List[Dict], config: Dict) -> List[Dict]:
    return [project(r, config) for r in records]
