"""Merge raw per-source records into one canonical record per candidate.

Match key: email (lowercased) if present on either side; otherwise normalized
full_name is used as a weaker fallback key. This is a known simplification --
documented as an edge case/scope cut.

Field-level conflict resolution uses a fixed source-priority order per field
group. Source priority isn't a quality judgment in general -- it's an
assumption about which source tends to be more reliable for that field type
(e.g. recruiter CSV is hand-entered for company/title, so trust it over a
resume's free text; but skills are richer in the resume).
"""
from typing import List, Dict
from normalize import normalize_phone, normalize_skill, normalize_date_to_yyyymm

FIELD_PRIORITY = {
    "current_company": ["csv", "resume"],
    "title": ["csv", "resume"],
    "full_name": ["csv", "resume"],
    "phone": ["csv", "resume"],
    "email": ["csv", "resume"],
}


def _match_key(record: Dict) -> str:
    raw = record["raw"]
    email = (raw.get("email") or "").strip().lower()
    if email:
        return f"email:{email}"
    name = (raw.get("full_name") or "").strip().lower()
    return f"name:{name}" if name else f"anon:{id(record)}"


def group_by_candidate(records: List[Dict]) -> Dict[str, List[Dict]]:
    groups: Dict[str, List[Dict]] = {}
    for r in records:
        key = _match_key(r)
        groups.setdefault(key, []).append(r)
    return groups


def _pick_winner(field: str, candidates: List[Dict]):
    """candidates: list of (value, source_type) tuples with non-null value."""
    priority = FIELD_PRIORITY.get(field, ["csv", "resume"])
    for src_type in priority:
        for value, stype in candidates:
            if stype == src_type:
                return value, stype
    return candidates[0] if candidates else (None, None)


def merge_group(records: List[Dict], candidate_id: str) -> Dict:
    provenance = []
    emails = set()
    phones = set()
    skills_seen: Dict[str, Dict] = {}  # canonical_skill -> {sources: set, hits: int}

    field_candidates: Dict[str, List] = {}
    for r in records:
        raw = r["raw"]
        stype = r["_source_type"]
        src = r["_source"]

        if raw.get("email"):
            emails.add(raw["email"].strip().lower())
        if raw.get("phone"):
            norm = normalize_phone(raw["phone"])
            if norm:
                phones.add(norm)
                provenance.append({"field": "phones", "source": src, "method": "regex+E164"})

        for fname in ("full_name", "current_company", "title"):
            if raw.get(fname):
                field_candidates.setdefault(fname, []).append((raw[fname], stype))

        for skill in raw.get("skills", []) or []:
            canon = normalize_skill(skill)
            entry = skills_seen.setdefault(canon, {"sources": set(), "hits": 0})
            entry["sources"].add(src)
            entry["hits"] += 1

    full_name, name_src = _pick_winner("full_name", field_candidates.get("full_name", []))
    if name_src:
        provenance.append({"field": "full_name", "source": name_src, "method": "source_priority"})

    company, company_src = _pick_winner("current_company", field_candidates.get("current_company", []))
    title, title_src = _pick_winner("title", field_candidates.get("title", []))

    experience = []
    if company or title:
        experience.append({
            "company": company,
            "title": title,
            "start": None,
            "end": None,
            "summary": None,
        })
        if company_src:
            provenance.append({"field": "experience.company", "source": company_src, "method": "source_priority"})
        if title_src:
            provenance.append({"field": "experience.title", "source": title_src, "method": "source_priority"})

    skills = []
    n_sources_total = len({r["_source"] for r in records})
    for canon, info in sorted(skills_seen.items()):
        conf = min(1.0, len(info["sources"]) / max(1, n_sources_total) + 0.4)
        skills.append({
            "name": canon,
            "confidence": round(conf, 2),
            "sources": sorted(info["sources"]),
        })
        provenance.append({"field": f"skills.{canon}", "source": ",".join(sorted(info["sources"])), "method": "keyword_match"})

    return {
        "candidate_id": candidate_id,
        "full_name": full_name,
        "emails": sorted(emails),
        "phones": sorted(phones),
        "location": {"city": None, "region": None, "country": None},
        "links": {"linkedin": None, "github": None, "portfolio": None, "other": []},
        "headline": None,
        "years_experience": None,
        "skills": skills,
        "experience": experience,
        "education": [],
        "provenance": provenance,
        "_sources_used": sorted({r["_source"] for r in records}),
    }


def merge_records(records: List[Dict]) -> List[Dict]:
    groups = group_by_candidate(records)
    profiles = []
    for i, (key, group_records) in enumerate(groups.items(), start=1):
        candidate_id = f"cand_{i:04d}"
        profiles.append(merge_group(group_records, candidate_id))
    return profiles
