"""Normalize raw field values into canonical formats."""
import re
from typing import Optional

try:
    import phonenumbers
except ImportError:
    phonenumbers = None

# Canonical skill names -> accepted synonyms/variants seen in the wild.
SKILL_CANONICAL_MAP = {
    "python": ["python", "python3", "py"],
    "javascript": ["javascript", "js"],
    "typescript": ["typescript", "ts"],
    "node.js": ["node.js", "node", "nodejs"],
    "machine learning": ["machine learning", "ml"],
    "c++": ["c++", "cpp"],
    "c#": ["c#", "csharp"],
}
_SYNONYM_TO_CANONICAL = {
    syn: canon for canon, syns in SKILL_CANONICAL_MAP.items() for syn in syns
}


def normalize_phone(raw: Optional[str], default_region: str = "US") -> Optional[str]:
    """Normalize to E.164. Returns None if unparseable -- never invent a number."""
    if not raw:
        return None
    if phonenumbers is None:
        digits = re.sub(r"\D", "", raw)
        return f"+{digits}" if digits else None
    try:
        parsed = phonenumbers.parse(raw, default_region)
        if not phonenumbers.is_valid_number(parsed):
            return None
        return phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.E164)
    except Exception:
        return None


def normalize_skill(raw: str) -> str:
    """Map a raw skill string to its canonical name, lowercased and trimmed."""
    cleaned = raw.strip().lower()
    return _SYNONYM_TO_CANONICAL.get(cleaned, cleaned)


def normalize_date_to_yyyymm(raw: Optional[str]) -> Optional[str]:
    """Best-effort normalization of a free-text date to YYYY-MM. Returns None on failure
    rather than guessing -- a wrong date is worse than a missing one."""
    if not raw:
        return None
    raw = raw.strip()
    m = re.match(r"^(\d{4})-(\d{2})$", raw)
    if m:
        return raw
    m = re.match(r"^(\d{4})$", raw)
    if m:
        return f"{raw}-01"
    return None
