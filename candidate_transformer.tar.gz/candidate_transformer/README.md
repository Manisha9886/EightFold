# Multi-Source Candidate Data Transformer

Merges candidate data from a recruiter CSV export and resume files (PDF/DOCX)
into one canonical, deduplicated profile per candidate, with confidence
scores and field-level provenance. Supports a runtime config that reshapes
the output schema without code changes.

## Pipeline

`detect → parse → normalize → merge → confidence → project (config) → validate`

- **detect**: classify each input file by extension (`detect.py`)
- **parse**: CSV rows → dicts (`parsers/csv_parser.py`); resume text →
  regex-extracted fields (`parsers/resume_parser.py`)
- **normalize**: phones → E.164, skills → canonical names (`normalize.py`)
- **merge**: group by email (fallback: normalized name), resolve field
  conflicts via fixed source-priority order, accumulate provenance
  (`merge.py`)
- **confidence**: deterministic per-skill and overall confidence scoring
  (`confidence.py`)
- **project**: apply runtime config to reshape canonical record into a
  custom output shape (`project.py`)
- **validate**: JSON-schema check before writing output (`validate.py`)

## How to run

```bash
pip install -r requirements.txt

# Default schema output
python cli.py --input-dir sample_inputs --out output.json

# Custom config output (subset/rename/normalize fields)
python cli.py --input-dir sample_inputs --config schema/example_config.json --out output_custom.json
```

Sample inputs live in `sample_inputs/` (a recruiter CSV + one DOCX resume,
sharing an email so they merge into one candidate). `output.json` and
`output_custom.json` in this repo are the actual produced output from those
sample inputs.

## Tests

```bash
python -m pytest tests/ -v
```

9 tests covering phone/skill normalization, CSV malformed-row handling,
missing-file handling, skill-matching false-positive regression (e.g. "go"
inside "Django"), and merge grouping/conflict resolution.

## Config format

See `schema/example_config.json`. Fields:
- `fields`: list of `{path, from, type, normalize, required}` — `path` is
  the output field name, `from` is the canonical-record path to pull from
  (supports `field[0]` and `field[].subfield` syntax), `normalize` is
  `"E164"` or `"canonical"`.
- `include_confidence` / `include_provenance`: booleans.
- `on_missing`: `"null" | "omit" | "error"`.

## Design decisions worth calling out

- **Match key**: email first, normalized full name as fallback. Two
  candidates with the same common name and no email would incorrectly
  merge — a known limitation under time pressure, not solved here.
- **Field conflict resolution**: fixed per-field source priority (e.g. CSV
  wins for `current_company`/`title`, since it's hand-entered recruiter
  data; resumes contribute richer `skills`). Not adaptive/learned.
- **Skill extraction**: regex/keyword match against a small fixed
  vocabulary, not NLP/ML-based. Deliberately simple, deterministic, and
  explainable; doesn't catch synonyms outside the vocabulary or plural
  forms (e.g. "REST APIs" vs "REST API").
- **Dates**: `normalize_date_to_yyyymm` exists but experience/education
  date extraction from free-text resumes isn't implemented — scoped out
  given the few-hours time budget. Returning `None` rather than guessing
  was the priority.
- **Confidence formula**: simple weighted sum (email presence, phone
  presence, multi-source corroboration, average skill confidence), not
  a learned model — documented in `confidence.py`.
- **Robustness**: corrupt PDFs, empty/malformed CSV rows, and unsupported
  file types are skipped with a warning rather than crashing the run
  (verified manually with a corrupt-PDF / empty-CSV / `.xyz` file edge
  case during development).

## What was descoped

- GitHub/LinkedIn source types (only resume + CSV implemented, per the
  "at least one structured + one unstructured" requirement).
- Location and education extraction from resumes.
- A UI — CLI only, per the assignment's stated lower priority on this.
