#!/usr/bin/env python3
"""CLI for the Multi-Source Candidate Data Transformer.

Usage:
  python cli.py --input-dir sample_inputs --out output.json
  python cli.py --input-dir sample_inputs --config schema/example_config.json --out output_custom.json
"""
import argparse
import json
import sys
from pathlib import Path

from detect import detect_source_type, SOURCE_CSV, SOURCE_RESUME_PDF, SOURCE_RESUME_DOCX
from parsers.csv_parser import parse_csv
from parsers.resume_parser import parse_resume
from merge import merge_records
from confidence import attach_confidence
from project import project_all
from validate import load_schema, validate_record


def collect_raw_records(input_dir: str):
    records = []
    skipped = []
    for path in sorted(Path(input_dir).iterdir()):
        if not path.is_file():
            continue
        stype = detect_source_type(str(path))
        if stype == SOURCE_CSV:
            records.extend(parse_csv(str(path), source_name=path.name))
        elif stype in (SOURCE_RESUME_PDF, SOURCE_RESUME_DOCX):
            rec = parse_resume(str(path), source_name=path.name)
            if rec.get("_parse_error"):
                skipped.append(path.name)
            else:
                records.append(rec)
        else:
            skipped.append(path.name)
    return records, skipped


def main():
    ap = argparse.ArgumentParser(description="Multi-Source Candidate Data Transformer")
    ap.add_argument("--input-dir", required=True, help="Directory of source files (csv/pdf/docx)")
    ap.add_argument("--config", default=None, help="Optional runtime projection config JSON")
    ap.add_argument("--schema", default="schema/default_schema.json", help="JSON schema for default-shape validation")
    ap.add_argument("--out", default="output.json", help="Output file path")
    args = ap.parse_args()

    raw_records, skipped = collect_raw_records(args.input_dir)
    if skipped:
        print(f"[warn] skipped {len(skipped)} unreadable/unsupported file(s): {skipped}", file=sys.stderr)
    if not raw_records:
        print("[warn] no usable records found -- writing empty output", file=sys.stderr)

    profiles = merge_records(raw_records)
    profiles = [attach_confidence(p) for p in profiles]
    for p in profiles:
        p.pop("_sources_used", None)

    if args.config:
        with open(args.config) as f:
            config = json.load(f)
        output = project_all(profiles, config)
    else:
        schema = load_schema(args.schema)
        for p in profiles:
            ok, errors = validate_record(p, schema)
            if not ok:
                print(f"[warn] candidate {p['candidate_id']} failed schema validation: {errors}", file=sys.stderr)
        output = profiles

    with open(args.out, "w") as f:
        json.dump(output, f, indent=2)
    print(f"Wrote {len(output)} candidate profile(s) to {args.out}")


if __name__ == "__main__":
    main()
