"""Extract structured-ish fields from unstructured resume text (PDF/DOCX).

This is intentionally heuristic/regex-based, not ML-based -- good enough to
demonstrate the pipeline, explainable, and deterministic. Documented as a
known limitation/scope cut in the design doc.
"""
import re
from typing import Dict, Optional

EMAIL_RE = re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}")
PHONE_RE = re.compile(r"(\+?\d[\d\-\.\(\)\s]{7,}\d)")

# Small canonical skill vocabulary used to detect skill mentions in free text.
# In a production system this would be a much larger curated taxonomy.
KNOWN_SKILLS = [
    "python", "java", "javascript", "typescript", "c++", "c#", "go", "rust",
    "sql", "react", "node.js", "django", "flask", "aws", "gcp", "azure",
    "docker", "kubernetes", "machine learning", "pandas", "numpy",
    "tensorflow", "pytorch", "git", "linux", "rest api", "graphql",
]


def _extract_text_pdf(path: str) -> str:
    import pdfplumber
    text = []
    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            text.append(page.extract_text() or "")
    return "\n".join(text)


def _extract_text_docx(path: str) -> str:
    import docx
    d = docx.Document(path)
    return "\n".join(p.text for p in d.paragraphs)


def _guess_name(text: str) -> Optional[str]:
    # Heuristic: first non-empty line that isn't an email/phone/url is likely the name.
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        if EMAIL_RE.search(line) or "http" in line.lower():
            continue
        if len(line.split()) <= 5:  # names are short lines, not paragraphs
            return line
    return None


def _extract_skills(text: str):
    lowered = text.lower()
    found = set()
    for skill in KNOWN_SKILLS:
        # word-boundary match avoids false positives like "go" inside "Django";
        # skills with non-alnum chars (c++, node.js) fall back to substring match.
        pattern_needed = skill.replace(" ", "").isalnum()
        if pattern_needed:
            if re.search(r"\b" + re.escape(skill) + r"\b", lowered):
                found.add(skill)
        elif skill in lowered:
            found.add(skill)
    return sorted(found)


def parse_resume(path: str, source_name: str = "resume") -> Dict:
    suffix = path.lower().rsplit(".", 1)[-1]
    try:
        if suffix == "pdf":
            text = _extract_text_pdf(path)
        elif suffix == "docx":
            text = _extract_text_docx(path)
        else:
            return {"_source": source_name, "_source_type": "resume", "raw": {}}
    except Exception:
        # corrupt/garbled file -- degrade gracefully
        return {"_source": source_name, "_source_type": "resume", "raw": {}, "_parse_error": True}

    if not text.strip():
        return {"_source": source_name, "_source_type": "resume", "raw": {}, "_parse_error": True}

    email_match = EMAIL_RE.search(text)
    phone_match = PHONE_RE.search(text)

    return {
        "_source": source_name,
        "_source_type": "resume",
        "raw": {
            "full_name": _guess_name(text),
            "email": email_match.group(0) if email_match else None,
            "phone": phone_match.group(0) if phone_match else None,
            "skills": _extract_skills(text),
            "raw_text": text,
        },
    }
