"""Parse recruiter CSV exports into raw candidate dicts.

Expected columns (case-insensitive, order-independent):
  name, email, phone, current_company, title

Any missing column is tolerated -- the field is simply absent from output.
"""
import csv
from typing import List, Dict


REQUIRED_ANY = {"name", "email"}  # a row with neither is treated as garbage and skipped


def parse_csv(path: str, source_name: str = "recruiter_csv") -> List[Dict]:
    records = []
    try:
        with open(path, newline="", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            # normalize header keys to lowercase/stripped so casing in the file doesn't matter
            reader.fieldnames = [
                (h or "").strip().lower() for h in (reader.fieldnames or [])
            ]
            for row in reader:
                row = {(k or "").strip().lower(): (v or "").strip() for k, v in row.items()}
                if not (row.get("name") or row.get("email")):
                    continue  # unusable row, skip rather than fabricate
                records.append({
                    "_source": source_name,
                    "_source_type": "csv",
                    "raw": {
                        "full_name": row.get("name") or None,
                        "email": row.get("email") or None,
                        "phone": row.get("phone") or None,
                        "current_company": row.get("current_company") or None,
                        "title": row.get("title") or None,
                    },
                })
    except FileNotFoundError:
        return []
    except (csv.Error, UnicodeDecodeError):
        # malformed file -- degrade gracefully, don't crash the whole pipeline
        return []
    return records
