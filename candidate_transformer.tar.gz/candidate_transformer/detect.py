"""Detect source type for a given input file."""
from pathlib import Path

SOURCE_CSV = "csv"
SOURCE_RESUME_PDF = "resume_pdf"
SOURCE_RESUME_DOCX = "resume_docx"
SOURCE_UNKNOWN = "unknown"


def detect_source_type(path: str) -> str:
    """Classify a file by extension. Cheap and deterministic on purpose --
    content-sniffing would add complexity with little payoff for this scope."""
    suffix = Path(path).suffix.lower()
    if suffix == ".csv":
        return SOURCE_CSV
    if suffix == ".pdf":
        return SOURCE_RESUME_PDF
    if suffix == ".docx":
        return SOURCE_RESUME_DOCX
    return SOURCE_UNKNOWN
