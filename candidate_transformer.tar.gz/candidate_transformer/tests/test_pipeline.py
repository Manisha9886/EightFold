import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from normalize import normalize_phone, normalize_skill
from merge import merge_records
from parsers.csv_parser import parse_csv
from parsers.resume_parser import _extract_skills


def test_normalize_phone_valid():
    assert normalize_phone("+1 415 555 0101") == "+14155550101"


def test_normalize_phone_invalid_returns_none():
    assert normalize_phone("not a phone") is None


def test_normalize_phone_none_input():
    assert normalize_phone(None) is None


def test_normalize_skill_synonym():
    assert normalize_skill("JS") == "javascript"
    assert normalize_skill("Python3") == "python"


def test_skill_extraction_no_false_positive_substring():
    # "go" should NOT match inside "Django" -- regression test for substring bug.
    # Note: plural forms (e.g. "APIs") aren't matched by design -- documented
    # limitation, not in scope to build a full stemmer for this assignment.
    text = "Experienced with Django and REST API design."
    skills = _extract_skills(text)
    assert "go" not in skills
    assert "rest api" in skills


def test_csv_parser_skips_malformed_rows():
    # write a temp csv with one good row and one fully empty row
    import tempfile
    content = "name,email,phone\nJane Doe,jane@example.com,555-1234\n,,\n"
    with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as f:
        f.write(content)
        path = f.name
    records = parse_csv(path)
    os.unlink(path)
    assert len(records) == 1
    assert records[0]["raw"]["full_name"] == "Jane Doe"


def test_csv_parser_missing_file_returns_empty():
    assert parse_csv("/nonexistent/path.csv") == []


def test_merge_groups_by_email():
    records = [
        {"_source": "a.csv", "_source_type": "csv", "raw": {"full_name": "Jane Doe", "email": "jane@example.com", "phone": "555-1234"}},
        {"_source": "b.docx", "_source_type": "resume", "raw": {"full_name": "Jane D.", "email": "jane@example.com", "skills": ["python"]}},
    ]
    profiles = merge_records(records)
    assert len(profiles) == 1
    assert profiles[0]["full_name"] == "Jane Doe"  # csv wins per source priority
    assert "python" in [s["name"] for s in profiles[0]["skills"]]


def test_merge_separates_distinct_candidates():
    records = [
        {"_source": "a.csv", "_source_type": "csv", "raw": {"full_name": "Jane Doe", "email": "jane@example.com"}},
        {"_source": "a.csv", "_source_type": "csv", "raw": {"full_name": "John Smith", "email": "john@example.com"}},
    ]
    profiles = merge_records(records)
    assert len(profiles) == 2
