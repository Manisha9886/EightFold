"""Compute an overall_confidence score for a merged candidate profile.

Deterministic formula, deliberately simple and explainable:
  - +0.3 if email present
  - +0.2 if phone present
  - +0.2 if 2+ sources contributed
  - + average skill confidence * 0.3 (0 if no skills)
Capped at 1.0.
"""
from typing import Dict


def compute_overall_confidence(profile: Dict) -> float:
    score = 0.0
    if profile.get("emails"):
        score += 0.3
    if profile.get("phones"):
        score += 0.2
    if len(profile.get("_sources_used", [])) >= 2:
        score += 0.2
    skills = profile.get("skills") or []
    if skills:
        avg_skill_conf = sum(s["confidence"] for s in skills) / len(skills)
        score += avg_skill_conf * 0.3
    return round(min(score, 1.0), 2)


def attach_confidence(profile: Dict) -> Dict:
    profile["overall_confidence"] = compute_overall_confidence(profile)
    return profile
